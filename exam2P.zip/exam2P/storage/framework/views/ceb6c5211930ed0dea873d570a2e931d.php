
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>
    <h1 class="display-1 text-center text-danger mt-4">EXAMEN 2DO PARCIAL</h1>
</body>
</html>

 
<?php /**PATH C:\laragon\www\exam2P\resources\views/welcome.blade.php ENDPATH**/ ?>