
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>
    <?php echo $__env->yieldContent('contenido'); ?>
</body>
</html>

 
<?php /**PATH C:\laragon\www\pw81\exam2P\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>