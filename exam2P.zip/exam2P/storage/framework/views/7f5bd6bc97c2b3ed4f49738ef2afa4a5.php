<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <title>Document</title>
</head>
<body>
    <h1 class="display-1 text-center text-info mt-5">EXAMEN PW2</h1>
    <div class="container-sm">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <h3 class="text-center mt-5">VIDEOJUEGOS</h3>
            <hr>
            <div class="mb-3">
              <label>Nombre: </label>
              <input type="text" class="form-control" name="txtNombre" value="<?php echo e(old('txtNombre')); ?>" required>
              
            </div>
            <div class="mb-3">
              <label>Fecha Publicación</label>
              <input type="text" class="form-control" name="txtFecha" value="<?php echo e(old('txtNombre')); ?>" required>
              
            </div>
            <div class="mb-3">
                <label>Videojuegos Vendidos</label>
                <input type="text" class="form-control" name="txtVendidos"  value="<?php echo e(old('txtNombre')); ?>"required>
                
              </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
          </form>
    </div>
    
</body>
</html>
    
    
<?php /**PATH C:\laragon\www\pw81\exam2P\resources\views/Formulario.blade.php ENDPATH**/ ?>