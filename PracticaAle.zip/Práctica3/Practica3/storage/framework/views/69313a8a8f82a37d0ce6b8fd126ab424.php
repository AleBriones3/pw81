


<article class="alert text-dark p-4" role="alert">
 
  <hr>
  <?php echo e($slot); ?>

</article> 




<?php /**PATH C:\laragon\www\pw81\Práctica3\Practica3\resources\views/components/alert.blade.php ENDPATH**/ ?>