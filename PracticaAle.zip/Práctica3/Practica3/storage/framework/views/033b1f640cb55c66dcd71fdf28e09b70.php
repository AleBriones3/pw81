<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type']); ?>
<?php foreach (array_filter((['type']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
  switch ($type) {
    case 'success':
      $clases="alert-success border-left border-success";
      break;
    
    case 'warning':
      $clases="alert-warning border-left border-warning";
      break;
    
    default:
      $clases="alert-info border-left border-info";
      break;
  }   
?>



<article class="alert text-dark p-4" role="alert">
  <h4 class="font-weight-bold <?php echo e($clases); ?>"><?php echo e($title); ?></h4>
  <hr>
  <?php echo e($slot); ?>

</article> 




<?php /**PATH C:\laragon\www\GitHub\PW181\Práctica3\Practica3\resources\views/components/alert.blade.php ENDPATH**/ ?>